# SAR_improved: work in progress (1 Nov 2026)

Copy the .sch/.sym files into  /home/ttuser/Documents/ADCAnalogDesign/SAR_improved/
(the schematics refer to that folder and to your nand2/nor2/inverter/comparator/sar_logic3_simple cells one level up).

| File | What it is | State |
|---|---|---|
| latch_comp.sch/.sym | Clocked StrongARM latch comparator (PMOS input) + NAND SR latch. Pins VDD VSS CLK INP INN -> OUT OUTB | **Done** (final sizing) |
| cdac3_v1, sar_adc3_v1 | Step 1 (area): same SAR as yours, unit cap 8x8 um (140 fF) instead of 10x10 x MF5 (1.08 pF). MIM area 512 um2 instead of 4000 um2 | Works, but 1 of 16 test codes wrong (see below); dummy-cap fix in progress |
| cdac3_v2, sar_adc3_v2 | Step 2 (energy): latch comparator instead of the always-on comparator, unit cap 4x4 um | Being simulated / tuned |
| cdac_vcm3, sar_logic_vcm3, sar_adc3_v3 | Step 3 (final): top-plate sampling + Vcm-based switching + replica node for the comparator | Being simulated / tuned |

## Results so far (tt corner, 27 C)

Baseline (your sar_adc3, 2 us per conversion): 43.9 pJ per conversion (VCC 41.3 pJ, VREF 2.6 pJ), 22.0 uW. 16/16 codes correct.

Step 1 (sar_adc3_v1), energy per conversion and codes wrong out of 16:
- 2000 ns: 43.2 pJ (VREF energy 2.63 -> 0.34 pJ), 1 wrong (VIN = 0.675 V gives 7 instead of 6)
- 500 ns: 11.9 pJ, 3 wrong;  300 ns: 7.5 pJ, 6 wrong;  200 ns: 5.1 pJ, 11 wrong
Why: the old comparator puts ~35 fF on REF, so REF(7) = 679 mV instead of 700 mV, plus its -5 mV offset at ADJ = 0.75 V.
Fix being applied: make the dummy capacitor smaller by exactly that parasitic (C - Cp), so REF sees 8C again.
The faster runs fail because the always-on comparator needs ~37 ns to decide 10 mV.

Latch comparator (latch_comp), VDD = 1.8 V:
- Systematic offset ~0.1 mV for input common mode 0.05 to 0.6 V
- Decision time 0.64 ns (1 mV overdrive), 0.54 ns (10 mV), 0.43 ns (300 mV)
- Energy 86-102 fJ per decision, zero static current
- Mismatch (sky130 Vth-mismatch numbers from the PDK, 39 samples): sigma 10.1 mV, worst 22 mV
- Kickback: a floating 160 fF input jumps ~20 mV during a decision -> -13 mV error if the other input is a stiff source;
  with a matched floating "replica" on the other input the error is 0 to -2 mV (kickback cancels).
- Sizing chosen after comparing 3 versions (results/latch_var.json): 4 um input pair used 139 fJ and kicked 38 mV; 2 um uses 96 fJ, 21 mV.

## scripts/
Python that writes the xschem files and runs the ngspice tests (paths inside are from my workspace).
gen_*.py = schematic generators, test_*.py / latch_*.py = simulations.
