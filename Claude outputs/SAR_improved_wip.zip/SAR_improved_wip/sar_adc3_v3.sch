v {xschem version=3.4.5 file_version=1.2
}
G {}
K {}
V {}
S {}
E {}
T {STEP 3 (final): 3-bit charge-redistribution SAR ADC: top-plate sampling + Vcm-based switching + latch comparator.
CDAC: 2C, C and a dummy with C = 4 x 4 um MIM (about 38 fF).  The comparator compares VX with VR (a replica node sampled to VCM = VREF/2).
Conversion: SMP (sample VIN on VX, VCM on VR)  ->  C2: decide D2 = (VIN > VREF/2)  ->  U2: move cap A to VREF (D2 = 0) or 0 V (D2 = 1)
->  C1: decide D1  ->  U1: move cap B  ->  C0: decide D0.   Code = D2 D1 D0.  Phases come from outside (or from a counter).} -400 -1000 0 0 0.3 0.3 {}
C {/home/ttuser/Documents/ADCAnalogDesign/SAR_improved/latch_comp.sym} 600 -300 0 0 {name=x1}
N 500 -340 480 -340 {}
C {lab_pin.sym} 480 -340 0 0 {name=l1 sig_type=std_logic lab=VCC}
N 500 -320 480 -320 {}
C {lab_pin.sym} 480 -320 0 0 {name=l2 sig_type=std_logic lab=VSS}
N 500 -300 480 -300 {}
C {lab_pin.sym} 480 -300 0 0 {name=l3 sig_type=std_logic lab=CLK}
N 500 -280 480 -280 {}
C {lab_pin.sym} 480 -280 0 0 {name=l4 sig_type=std_logic lab=VX}
N 500 -260 480 -260 {}
C {lab_pin.sym} 480 -260 0 0 {name=l5 sig_type=std_logic lab=VR}
N 700 -340 720 -340 {}
C {lab_pin.sym} 720 -340 0 1 {name=l6 sig_type=std_logic lab=COM}
N 700 -320 720 -320 {}
C {lab_pin.sym} 720 -320 0 1 {name=l7 sig_type=std_logic lab=COMB}
C {/home/ttuser/Documents/ADCAnalogDesign/SAR_improved/cdac_vcm3.sym} 1300 -300 0 0 {name=x2}
N 1190 -430 1170 -430 {}
C {lab_pin.sym} 1170 -430 0 0 {name=l8 sig_type=std_logic lab=VCC}
N 1190 -410 1170 -410 {}
C {lab_pin.sym} 1170 -410 0 0 {name=l9 sig_type=std_logic lab=VSS}
N 1190 -390 1170 -390 {}
C {lab_pin.sym} 1170 -390 0 0 {name=l10 sig_type=std_logic lab=VREF}
N 1190 -370 1170 -370 {}
C {lab_pin.sym} 1170 -370 0 0 {name=l11 sig_type=std_logic lab=VCM}
N 1190 -350 1170 -350 {}
C {lab_pin.sym} 1170 -350 0 0 {name=l12 sig_type=std_logic lab=VIN}
N 1190 -330 1170 -330 {}
C {lab_pin.sym} 1170 -330 0 0 {name=l13 sig_type=std_logic lab=SMP}
N 1190 -310 1170 -310 {}
C {lab_pin.sym} 1170 -310 0 0 {name=l14 sig_type=std_logic lab=PGA}
N 1190 -290 1170 -290 {}
C {lab_pin.sym} 1170 -290 0 0 {name=l15 sig_type=std_logic lab=NGA}
N 1190 -270 1170 -270 {}
C {lab_pin.sym} 1170 -270 0 0 {name=l16 sig_type=std_logic lab=EA}
N 1190 -250 1170 -250 {}
C {lab_pin.sym} 1170 -250 0 0 {name=l17 sig_type=std_logic lab=EAB}
N 1190 -230 1170 -230 {}
C {lab_pin.sym} 1170 -230 0 0 {name=l18 sig_type=std_logic lab=PGB}
N 1190 -210 1170 -210 {}
C {lab_pin.sym} 1170 -210 0 0 {name=l19 sig_type=std_logic lab=NGB}
N 1190 -190 1170 -190 {}
C {lab_pin.sym} 1170 -190 0 0 {name=l20 sig_type=std_logic lab=EB}
N 1190 -170 1170 -170 {}
C {lab_pin.sym} 1170 -170 0 0 {name=l21 sig_type=std_logic lab=EBB}
N 1410 -430 1430 -430 {}
C {lab_pin.sym} 1430 -430 0 1 {name=l22 sig_type=std_logic lab=VX}
N 1410 -410 1430 -410 {}
C {lab_pin.sym} 1430 -410 0 1 {name=l23 sig_type=std_logic lab=VR}
C {/home/ttuser/Documents/ADCAnalogDesign/SAR_improved/sar_logic_vcm3.sym} 2100 -300 0 0 {name=x3}
N 1990 -410 1970 -410 {}
C {lab_pin.sym} 1970 -410 0 0 {name=l24 sig_type=std_logic lab=VCC}
N 1990 -390 1970 -390 {}
C {lab_pin.sym} 1970 -390 0 0 {name=l25 sig_type=std_logic lab=VSS}
N 1990 -370 1970 -370 {}
C {lab_pin.sym} 1970 -370 0 0 {name=l26 sig_type=std_logic lab=SMP}
N 1990 -350 1970 -350 {}
C {lab_pin.sym} 1970 -350 0 0 {name=l27 sig_type=std_logic lab=C2}
N 1990 -330 1970 -330 {}
C {lab_pin.sym} 1970 -330 0 0 {name=l28 sig_type=std_logic lab=C1}
N 1990 -310 1970 -310 {}
C {lab_pin.sym} 1970 -310 0 0 {name=l29 sig_type=std_logic lab=C0}
N 1990 -290 1970 -290 {}
C {lab_pin.sym} 1970 -290 0 0 {name=l30 sig_type=std_logic lab=U2}
N 1990 -270 1970 -270 {}
C {lab_pin.sym} 1970 -270 0 0 {name=l31 sig_type=std_logic lab=U1}
N 1990 -250 1970 -250 {}
C {lab_pin.sym} 1970 -250 0 0 {name=l32 sig_type=std_logic lab=COM}
N 1990 -230 1970 -230 {}
C {lab_pin.sym} 1970 -230 0 0 {name=l33 sig_type=std_logic lab=COMB}
N 2210 -410 2230 -410 {}
C {lab_pin.sym} 2230 -410 0 1 {name=l34 sig_type=std_logic lab=CLK}
N 2210 -390 2230 -390 {}
C {lab_pin.sym} 2230 -390 0 1 {name=l35 sig_type=std_logic lab=D2}
N 2210 -370 2230 -370 {}
C {lab_pin.sym} 2230 -370 0 1 {name=l36 sig_type=std_logic lab=D1}
N 2210 -350 2230 -350 {}
C {lab_pin.sym} 2230 -350 0 1 {name=l37 sig_type=std_logic lab=D0}
N 2210 -330 2230 -330 {}
C {lab_pin.sym} 2230 -330 0 1 {name=l38 sig_type=std_logic lab=PGA}
N 2210 -310 2230 -310 {}
C {lab_pin.sym} 2230 -310 0 1 {name=l39 sig_type=std_logic lab=NGA}
N 2210 -290 2230 -290 {}
C {lab_pin.sym} 2230 -290 0 1 {name=l40 sig_type=std_logic lab=EA}
N 2210 -270 2230 -270 {}
C {lab_pin.sym} 2230 -270 0 1 {name=l41 sig_type=std_logic lab=EAB}
N 2210 -250 2230 -250 {}
C {lab_pin.sym} 2230 -250 0 1 {name=l42 sig_type=std_logic lab=PGB}
N 2210 -230 2230 -230 {}
C {lab_pin.sym} 2230 -230 0 1 {name=l43 sig_type=std_logic lab=NGB}
N 2210 -210 2230 -210 {}
C {lab_pin.sym} 2230 -210 0 1 {name=l44 sig_type=std_logic lab=EB}
N 2210 -190 2230 -190 {}
C {lab_pin.sym} 2230 -190 0 1 {name=l45 sig_type=std_logic lab=EBB}
C {ipin.sym} -400 -700 0 0 {name=p1 lab=VCC}
C {ipin.sym} -400 -670 0 0 {name=p2 lab=VSS}
C {ipin.sym} -400 -640 0 0 {name=p3 lab=VREF}
C {ipin.sym} -400 -610 0 0 {name=p4 lab=VCM}
C {ipin.sym} -400 -580 0 0 {name=p5 lab=VIN}
C {ipin.sym} -400 -550 0 0 {name=p6 lab=SMP}
C {ipin.sym} -400 -520 0 0 {name=p7 lab=C2}
C {ipin.sym} -400 -490 0 0 {name=p8 lab=U2}
C {ipin.sym} -400 -460 0 0 {name=p9 lab=C1}
C {ipin.sym} -400 -430 0 0 {name=p10 lab=U1}
C {ipin.sym} -400 -400 0 0 {name=p11 lab=C0}
C {opin.sym} -400 -370 0 0 {name=p12 lab=D2}
C {opin.sym} -400 -340 0 0 {name=p13 lab=D1}
C {opin.sym} -400 -310 0 0 {name=p14 lab=D0}
